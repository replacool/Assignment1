package com.company;

public class SoftwareDevelopment extends Department {


    public SoftwareDevelopment(String name, int numberOfWorker) {

        super(name,numberOfWorker);

    }
    // Erase the content. Fill in the blanks. It returns number.
    public static int getNumber() {


        return number;

    }

}
