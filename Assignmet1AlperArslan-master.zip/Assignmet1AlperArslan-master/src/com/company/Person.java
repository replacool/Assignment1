package com.company;

public abstract class Person {

    // Do not change anything in this class

    protected String name;
    public static int number;

    public abstract double calculateSalary();
}

